﻿namespace MySql.Parser
{
	partial class MySQL51Lexer
	{
	}
}
